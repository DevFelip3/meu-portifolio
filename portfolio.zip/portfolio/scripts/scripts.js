/*
    Arquivo: script.js
    Autor: Luiz Felipe Alves da Silva
    RU: 4965346
    Descrição: Funcionalidades JavaScript para o portfólio
*/

document.addEventListener('DOMContentLoaded', function() {
    // Ativa o menu correspondente à página atual
    const currentPage = location.pathname.split('/').pop();
    document.querySelectorAll('.menu a').forEach(link => {
        link.classList.toggle('active', link.getAttribute('href') === currentPage);
    });

    // Atualiza o ano no footer automaticamente
    const yearElement = document.getElementById('current-year');
    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }

    // Validação do formulário de contato
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const message = document.getElementById('message');
            let isValid = true;

            // Valida campos obrigatórios
            [name, email, message].forEach(field => {
                field.classList.toggle('error', !field.value.trim());
                if (!field.value.trim()) isValid = false;
            });

            // Valida formato do email
            if (isValid && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
                email.classList.add('error');
                alert('Por favor, insira um e-mail válido.');
                return;
            }

            // Se tudo estiver válido
            if (isValid) {
                alert('Mensagem enviada com sucesso! Em breve entrarei em contato.');
                contactForm.reset();
            }
        });
    }
});